const bodyParser = require("body-parser");
const express = require("express");
const app = express();
const path =require("path")
const ejs= require('ejs');
const session = require("express-session")
const db =require("./schemas/database");



app.set("view engine", "ejs");

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"))
// app.set("views", path.join(__dirname,"views"))
// app.use(session({
//     secret : "random letters",
//     resave : true,
//     setUninitialized: false,
//     saveUninitialized: true
// }))
const port = 3000;

app.get("/", function (req, res) {
    res.render("landingPageIndex")
});
app.get("/", function (req, res) {
    res.render("AboutUs2")
});
app.get("/", function (req, res) {
    res.render("nonProfit")
});
app.get("/about_us", (req, res)=>{
res.render("about_us");
})
app.get("/services", (req, res)=>{
    res.render("services");
})
app.get("/user", (req, res)=>{
    res.render("User");
})
app.get("/ngos", (req, res)=>{
    res.render("ngos");
})
app.get("/contact", (req, res)=>{
    res.render("contact");
})
app.get("/log", (req, res)=>{
    res.render("log");
})
app.get("/register", (req, res)=>{
    res.render("register-layout");
})
app.get("/Faq", (req, res)=>{
    res.render("faq");
})
app.get("/TermsCondition", (req, res)=>{
    res.render("TermsCondition");
})


const loginRoute=require("./routes/loginRoutes");

app.use("/log", loginRoute);

app.get("/register", (req, res)=>{
    res.render("register-layout");
})
app.get("/user", (req, res)=>{
    res.render("user");
})



app.post("/registerForm", (req, res)=>{
    
})
const registerRoute=require("./routes/registerRoutes");
app.use("/register", registerRoute);


app.listen(port, () => console.log(`Example app listening on port ${port}!`));
