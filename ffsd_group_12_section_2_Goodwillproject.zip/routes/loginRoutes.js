const express = require('express');
const app = express();
const router = express.Router();
const bodyparser = require("body-parser");
const { urlencoded } = require('body-parser');
// const User = require('../schemas/Userschema');
// const bcrypt =require('bcrypt');
const databasequeries= require("../sqldbs/databasequeries");
const db =require("../sqldbs/database");

app.set("view engine", "ejs");
app.set("views", "views");

app.use(bodyparser, urlencoded({ extended: false }));
router.get("/", (req, res, next) => {

   return res.status(200).render("log");
})

router.post("/",async(req,res,next)=>{
console.log(req.body);
    var payload = req.body;
    var flag1 =0,flag2=0;
    if(req.body.logUsername && req.body.logPassword)
    {
        let q = `select * from web_check where username = $username and password = $password`;

         db.get(q,{$username: payload.logUsername, $password: payload.logPassword},async(err,row)=>
        {
            if(err || !row){
                // alert("Incorrect username or password");
               return res.status(200).render("log");
            }

           else 
           {
            return res.render("User", {Name: req.body.logUsername, Password: req.body.logPassword});
           }
        })
    }

})
module.exports=router;