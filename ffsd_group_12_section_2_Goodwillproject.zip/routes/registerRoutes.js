const express = require('express');
const app = express();
const router = express.Router();
const bodyparser = require("body-parser");
// const User = require("../schemas/Userschema");
const databasequeries= require("../sqldbs/databasequeries");
const db =require("../sqldbs/database");
// const bcrypt = require("bcrypt");
const tablename = "web_practice";

app.set("view engine", "pug");
app.set("views", "views");

app.use(bodyparser.urlencoded({ extended: false }));

router.get("/", (req, res, next) => {

    res.status(200).render("register");
})
router.post("/", async (req, res, next) => {
    // console.log("hi");
    let username = req.body.username.trim();
    let email = req.body.email.trim();
    let password = req.body.password;

if(username && email)
{
    databasequeries.crt_table("web_check",db);
    databasequeries.insrt_val(db,"web_check",username,email,password);
    databasequeries.get_table("web_check", db);
}

})
module.exports=router;