const sqlite = require("sqlite3");

const filePath = "./sql_dbs";

function createDbConnection() {
    const db = new sqlite.Database(filePath, (error) => {
        if (error) {
            return console.error(error);
        }
    })

    console.log("database connected!");

    return db;
}


const db = createDbConnection();

module.exports = db;
